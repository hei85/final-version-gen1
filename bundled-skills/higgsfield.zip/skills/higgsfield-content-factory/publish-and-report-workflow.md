---
name: higgsfield-content-factory
description: >
  Publish + report satellite for higgsfield-content-factory. Covers Stage 4 (schedule &
  publish the generated campaign to Meta Ads, or export a content calendar) and Stage 5
  (cost-comparison report — actual Higgsfield credit spend vs an estimated traditional
  production cost). This tail is isolated from the parent because it carries the most
  connector-dependent material (the Meta Ads integration) and the most estimate-based
  material (the traditional-cost model), both of which need heavy "not verified / user-
  overridable" framing. Consulted from parent SKILL.md § 7 when the user reaches the
  publish or report stage of the campaign pipeline.
user-invocable: false
metadata:
  tags: [higgsfield, content-factory, meta-ads, publish, scheduling, cost-report, savings, satellite, workflow]
  version: 1.0.0
  updated: 2026-06-03
  parent: higgsfield
---

# Content Factory — Publish & Report (Stages 4–5)

The tail of the Content Factory pipeline: schedule the generated campaign to
ads (Stage 4) and report cost savings (Stage 5). This is the most
speculative part of the pipeline — the Meta Ads integration is
connector-dependent and the traditional-cost model is an estimate, not a
Higgsfield fact. Both are framed accordingly below.

> **Source-evidence boundary for this satellite.** The Meta Ads connector
> schema (its exact tool/parameter signatures, ad-account auto-detection,
> install-card behavior) is **not** part of this skill's verified corpus —
> treat all Meta mechanics as connector-dependent and verify them in the
> user's actual environment. The traditional-cost figures are **industry-
> average estimates, not Higgsfield prices and not a quote** — they must be
> presented as a user-overridable default rate card with a methodology
> disclaimer, never as authoritative numbers.

---

## Stage 4 — Schedule & publish to Meta Ads

### 1. Connection check first

Before anything else in Stage 4, ask (buttons) whether the user's Meta Ads
connector is actually connected:

> "Quick check before we schedule — is your Meta connector linked to Meta
> Ads?"
> - "Yes — connected"
> - "Not connected — help me install it"
> - "Skip live scheduling — give me an exportable calendar instead"

**If connected** → proceed to the campaign-details card (step 2).

**If not connected** → surface the connector-install path: search the MCP
connector registry for a Meta Ads connector and offer an install card the
user can authenticate with one click, with a manual fallback ("open Settings
→ Connections in your client and search for a Meta Ads connector"). After the
user reports the install is done, re-run the connection check. *The exact
registry/connector tool names vary by client and are connector-dependent —
do not assert a fixed Meta tool signature.*

**If skip** → export `[brand]-content-calendar.csv` with columns: Date · Time
· Format · Preset · Video filename · Image filename · Caption · Goal · Notes.
The user can hand it to a media buyer or paste it into Ads Manager. Skip the
rest of Stage 4 and go to Stage 5.

### 2. Campaign details (buttons, only if connected)

One button round-trip: campaign objective (Awareness / Traffic / Conversions
/ Mixed), budget tier (with a recommended default), date range (match the
content-plan dates / next 30 days / custom). If the connector returns
multiple ad accounts, present them as a button list; otherwise use the one
returned.

### 3. Schedule review (button approval)

Present the calendar, then confirm: "Schedule looks good?" — schedule
everything / start with week 1 only / adjust dates first.

### 4. Create & schedule

Per batch, through the Meta connector: create the campaign with the chosen
objective, create ad sets with targeting (ask audience intent via buttons —
lookalike from product / saved audience / define new), attach the generated
Higgsfield videos and images as creatives, and schedule per the plan's dates.
*All of this runs through whatever Meta connector the user has installed; this
skill specifies the workflow, not the connector's API.*

### 5. Confirm

Summarize the schedule by week, then ask whether to continue to the cost
report.

---

## Stage 5 — Cost-comparison report

Render a report comparing the **actual Higgsfield credit + USD spend** for
this campaign against an **estimated cost of producing the same volume
traditionally**.

### 1. Pull actual Higgsfield spend

Pull the real credit spend for the campaign window from the user's
transaction history (the marketing-studio sub-skill § 12 documents the
`transactions` pull). Filter to jobs created during the Stage 3 generation
window and sum credits per preset, per image model, and in total.

Convert credits → USD using **the user's own plan rate** — and disclose the
rate explicitly. If the rate isn't surfaced, present **credits only** and note
that USD is plan-dependent. Do not assert a canonical per-credit USD rate;
plan rates vary.

### 2. Apply a traditional-cost model — as an overridable estimate

Compare the generated volume against an estimated traditional production cost.
**The cost model is not Higgsfield data.** Present it as:

- A **user-overridable default rate card.** If the user has their own rate
  card, use theirs.
- A **low / mid / high range per asset type**, never a single number.
- Explicitly labeled **"industry-average estimates, not a quote; prices vary
  by region and agency tier."**

The asset-type taxonomy the model prices: UGC creator video, Product Review,
Tutorial/Recipe, Unboxing, Hyper Motion CGI hero, TV Spot, Wild Card / FOOH
stunt, UGC / Pro Virtual Try On, social still, hero banner, product
photoshoot with/without people. (Illustrative default figures may seed the
rate card, but they must carry the estimate disclaimer and remain editable —
they are not authoritative and not Higgsfield prices.)

### 3. Compute savings

Per asset type: `traditional_{low,mid,high} = Σ(count × rate)`.
`higgsfield_usd = total_credits × disclosed_plan_rate`.
`savings_pct = 1 − higgsfield_usd / traditional_mid` (cap 99.99%). Report a
time-savings line too (render hours vs traditional weeks), framed as a
typical-turnaround comparison rather than a guarantee.

### 4. Render the report

A polished document with: a hero savings card, a volume summary, the
Higgsfield spend breakdown (credits + disclosed-rate USD), the traditional
estimate (same volumes at low/mid/high), a side-by-side comparison (simple
HTML/CSS bars — no external chart libs), a time-savings panel, and a
**methodology footer** disclosing that traditional costs are industry-average
estimates (not a quote), Higgsfield USD uses the user's plan rate at report
time, and prices vary by region/agency tier. Match the brand header treatment
used by the content plan for consistency.

### 5. Present

Show the saved report and offer next steps via buttons (close pipeline /
email the report / adjust the rate card and re-render / run again for another
product).

---

## Source acknowledgment

Translated from Stages 4–5 of Adil Aliyev's `higgsfield-content-factory`
source skill. The Meta Ads scheduling workflow and the cost-comparison report
structure are the source's; this satellite deliberately **downgrades** two
classes of claim per the DISCIPLINE.md source-evidence boundary: (1) the Meta
connector's tool/parameter signatures and auto-detect behavior are treated as
connector-dependent and unverified rather than asserted as fact, and (2) the
traditional-production dollar figures are presented as a user-overridable
estimate with a mandatory methodology disclaimer rather than as authoritative
or Higgsfield-sourced numbers. The live-spend pull defers to
`../higgsfield-marketing-studio/SKILL.md` § 12.
