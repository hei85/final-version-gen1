---
name: higgsfield-content-factory
description: "Use when the user wants to run a full ad-campaign pipeline on top of Higgsfield Marketing Studio — 'create a campaign', 'build a content plan', 'run the content pipeline', 'generate 100 UGC videos', 'plan and schedule a launch', 'make a batch of ads from my product', or 'how much did this save vs traditional production'. Covers the 5-stage orchestration (Research → Plan → Generate → Publish → Report), the UGC-first 5-format campaign mix (UGC Entertainment, Street Interview, Unboxing, Product Review, ASMR), the even-split allocation math, button-driven onboarding, the per-batch generation gate, and the publish + cost-report tail (satellite). Defers all Marketing Studio API ground-truth (presets, params, hooks, avatars) to higgsfield-marketing-studio."
user-invocable: true
metadata:
  tags: [higgsfield, content-factory, campaign, pipeline, orchestration, ugc, marketing-studio, content-plan, batch-generation, ad-campaign]
  version: 1.0.0
  updated: 2026-06-03
  parent: higgsfield
---

# Higgsfield Content Factory — Campaign Orchestration Pipeline

A 5-stage pipeline that runs a full ad campaign on top of Higgsfield
Marketing Studio: **Research → Plan → Generate → Publish → Report.** Where
`higgsfield-marketing-studio` is the *engine reference* (what the presets,
parameters, hooks, and avatars are), Content Factory is the *orchestration
layer* that drives a whole campaign turn by turn — researching trends,
planning a dated content calendar, generating in batches, scheduling to ads,
and reporting cost savings.

Translated from Adil Aliyev's `higgsfield-content-factory` source skill, per
the v3.7.13 / v3.7.16 translation precedent. **All Marketing Studio API
ground-truth — preset slugs, parameter schema, hook/setting/avatar handling
— lives in `../higgsfield-marketing-studio/SKILL.md` and is NOT restated
here.** This sub-skill carries the pipeline scaffolding the marketing-studio
sub-skill deliberately deferred. The publish + cost-report tail (Stages 4–5)
lives in the companion `publish-and-report-workflow.md` satellite.

---

## 1. Two operating principles

**Content is UGC-first.** Every campaign defaults to a heavy share of
UGC-family content — talking-head clips, honest reviews, ASMR close-ups,
unboxing reveals. Hyper Motion, TV Spot, and Wild Card stay available but
off the default mix. Every video idea must be producible inside one live
Marketing Studio preset within its duration cap (see marketing-studio § 3 /
§ 7 for the canonical preset list and limits).

**The interaction is button-driven.** Every clarifying question is asked as a
2–4 option button choice (one round-trip), never a free-form "type your
answer" for navigation, confirmation, or routing. Free-form typing is
reserved for content the user must originate — and even then, always offer a
smart default they can accept with one click. The only non-button steps are
attaching a product image or pasting a product URL (both click-based file
actions).

> **User-facing language rule (HARD).** The user is not a developer. Do not
> narrate technical mechanics — no MCP tool names, no UUID resolution, no
> "running parallel searches," no enhanced-prompt internals. All of that runs
> silently. Send one plain-language stage banner when each stage starts, a
> brief "Stage N done — [deliverable]" between stages, then the next banner.
> The user sees a clean narrative arc, not a tool log. If the user asks "how
> does it work under the hood," then explain.

### Stage banners

Send one banner per stage, in plain language (no tool names):

| Stage | Banner |
|---|---|
| 1 | **🔍 Research & ideas — starting now.** Scanning what's trending this week in your niche across Instagram, TikTok, and YouTube, then turning it into 15+ viral video ideas for your brand. |
| 2 | **🗂️ Content plan — starting now.** Building your full video content plan as a polished document, every video mapped, dated, and ready to generate. |
| 3 | **🎬 Generating videos — starting now.** Producing your videos in Marketing Studio, one preset at a time. I'll ask before each batch fires, so you stay in control. |
| 3 (images) | **🖼️ Image asset pack — starting now.** Generating your social posts, hero banners, and product stills via GPT Image 2.0. |
| 4 | **📅 Scheduling to ads — starting now.** Setting up campaigns and scheduling across the calendar you approved. |
| 5 | **💰 Cost report — starting now.** Compiling what you spent on Higgsfield versus what this volume would cost the traditional way. |

---

## 2. Onboarding — one message, all buttons, no pauses

Ask the onboarding questions in a **single** button round-trip at the start.
Do not ask them sequentially; do not pause between onboarding and the product
request.

- **A — Higgsfield connection:** "Yes — connected" · "Not yet — I'll connect
  now" · "Skip — research only."
- **B — Starting stage:** Stage 1 full pipeline (needs a product) · Stage 2
  build content plan (have a brief) · Stage 3 generate now (have a plan) ·
  Stage 4 schedule (content ready). A product image with no other context
  defaults to Stage 1.
- **C — Video volume:** 50 · 100 (recommended) · 150 · 200 · Other (any
  number). Store as `[VIDEO_COUNT]`.
- **D — The product:** "Attach your product image OR drop a URL — that's all
  I need to start." Skip D if a product is already attached. For Stage 3/4,
  swap D for "drop your existing content plan."

Send A + B + C as buttons and the product-attach prompt in the **same**
message; once answered, proceed straight to the chosen stage with no extra
confirmation.

> Compute the per-format split silently the instant `[VIDEO_COUNT]` locks in
> — do **not** announce the breakdown here. It surfaces later, woven into the
> Stage 1 brief as a consequence of what the research showed, so it reads as
> a trend-driven choice rather than a config card.

---

## 3. The campaign mix — 5 UGC formats (even split)

Every campaign distributes evenly across five viral UGC formats. Cinematic
secondary types (Hyper Motion / TV Spot / Wild Card) stay off-default — used
only when the user explicitly asks.

| # | Format | Share | What it is |
|---|---|---|---|
| 1 | **UGC Entertainment** | 20% | challenge / dare / entertainment-first; the product is the punchline |
| 2 | **Street Interview** | 20% | sidewalk stranger interviews where the product appears; high-trust "real people" feel |
| 3 | **Unboxing** | 20% | premium reveal energy — hands, packaging, the discovery moment |
| 4 | **Product Review** | 20% | honest talking-head; product in hand, label read aloud, ranking |
| 5 | **ASMR** | 20% | sound-led close-ups; caption-only, audible product handling |

**Allocation math.** `per_format = floor(VIDEO_COUNT / 5)`. If `VIDEO_COUNT`
doesn't divide evenly, distribute the remainder one-per-format from format 1.
Examples: 100 → 20/20/20/20/20; 50 → 10×5; 17 → 4/4/3/3/3.

This is the **default** mix and is user-overridable. The default share is a
craft choice (UGC-first), not a platform rule.

### Format → preset routing

Each format maps to a Marketing Studio preset. **Route preset selection
through the canonical mechanism documented in `../higgsfield-marketing-studio/SKILL.md`
§ 3** (slug naming is canonical there; routing mode lives on a separate MCP
call). At a glance:

- Formats 1 (Entertainment), 2 (Street Interview), 5 (ASMR) → the **UGC**
  preset; what differentiates them is the system hook, the setting, the audio
  flag, and the prompt content — not a separate preset.
- Format 3 (Unboxing) → the **Unboxing** preset.
- Format 4 (Product Review) → the **Product Review** preset.

> Do not hardcode hook/setting/avatar UUIDs or invent a `generate_video.mode`
> slug. Enumerate hooks/settings live (marketing-studio § 4 live-enumeration
> discipline) and pass the resolved IDs at generation time.

### Concept seeds (vary within each format)

No two videos in the same format should be the same concept. Pull from seeds
like: blind taste try, "$100 to try it" street challenge, will-it-pour
(Entertainment); "rate it out of 10," "sing for the product," blind opinion
→ brand reveal (Street Interview); trio reveal, ribbon-pull solo drop,
subscription-box drop (Unboxing); two-ingredient test, fridge-ranking,
7-day diary (Product Review); macro cap-unscrew + glug pour, condensation
slide, spoon-clink ice-drop (ASMR).

### ASMR is a style, not a preset

Render ASMR as the UGC preset with audio on, an intimate low-noise setting
(Kitchen / Bathroom / Bedroom), usually no system hook, and a prompt focused
on close-up handling sounds (cap unscrew, pour, glass clink, condensation).
No talking; caption-only or silent open.

---

## 4. Stage 1 — Trend research & viral ideas

> All research from live web searches; every idea validated against live
> Marketing Studio capability; UGC-first weighting.

1. **Probe capability silently.** Pull the current preset / hook / setting
   picklists live (marketing-studio § 4 / § 5 enumeration). Cache the hook +
   setting IDs for Stage 3. Never narrate this.
2. **Auto-detect product & niche** from the image or URL — do not ask the
   user to confirm.
3. **Run trend research** — a spread of web searches across the product's
   niche on the major platforms, plus at least two source-page fetches, run
   silently.
4. **Synthesize a Viral Content Brief** (UGC-first): 15+ idea cards, each
   tied to a format + preset, with the campaign's format breakdown woven in
   as a consequence of what the research surfaced.
5. **Producibility self-check** before adding any idea — every idea must be
   renderable inside one preset within the duration cap. Ideas needing
   lip-sync from non-human characters, multi-character coordinated dialogue,
   >15s single clips, or split-screen are **out** (or routed to an escape-
   hatch model — see § 6).
6. **Approve via buttons** before moving to Stage 2.

## 5. Stage 2 — Video content plan

Turn the approved brief into a dated content plan: one row per video
(`[VIDEO_COUNT]` rows), bucketed by the 5 formats, each with its format,
preset, concept, hook/setting intent, and a calendar date. Render it as a
polished, saved document deliverable the user can review and approve before
any generation fires. Interleave dates so formats rotate across the calendar
rather than clustering.

## 6. Stage 3 — Generate in Marketing Studio

> The point of failure-avoidance here is the **per-batch gate**: never fire a
> whole campaign at once.

1. **Upload the product silently** and register it (marketing-studio § 6).
2. **Resolve hooks / settings / avatars at runtime** per the cached
   picklists; never hardcode IDs.
3. **Generate one preset batch at a time**, and **ask before each batch
   fires** with a button gate ("Generate the 20 UGC Entertainment videos
   now?"). This keeps the user in control and prevents a runaway spend.
4. **No on-screen text in prompts** — Marketing Studio renders text
   unreliably; keep copy out of the generation and add it in post or via the
   image pack.
5. **Image asset pack** (optional) — generate social posts / hero banners /
   product stills via GPT Image 2.0, scaling the count from `[VIDEO_COUNT]`
   (see `../higgsfield-gpt-image-2/SKILL.md` for prompt craft; the count
   split skews toward social posts, then hero, then with/without-people
   stills). A **standalone image-pack mode** skips the videos entirely.
6. **Handle failures** by re-resolving the picklist and retrying the single
   failed batch, not the whole campaign.

### Escape hatch — ideas Marketing Studio can't render

If an idea genuinely needs lip-sync, longer narrative, or multi-shot
continuity, label it **"Outside Marketing Studio"** and route to Wan 2.7
(synchronized audio + character-consistent), Veo 3.1 (cinematic, audio-
friendly), Cinema Studio Video 3.0 (cinema-grade), Seedance 2.0 (reference-
driven, multi-SKU), or Kling 3.0 (multi-shot, motion transfer). Use sparingly
— UGC-first means most ideas stay inside Marketing Studio.

## 7. Stages 4–5 — Publish & report

Stage 4 (schedule & publish to Meta Ads) and Stage 5 (cost-comparison report)
live in the companion **`publish-and-report-workflow.md`** satellite. That
tail carries the most connector-dependent and estimate-based material, so its
caveats are isolated there.

---

## 8. Hard rules (consolidated)

- Button-driven navigation; free-form typing only for user-originated
  content, always with a one-click default.
- 5-format even split as the default mix; user-overridable.
- Producibility check before any idea ships to the plan.
- Per-batch generation gate — confirm before each batch fires.
- Hooks are visual scene templates, not verbal copy; never confuse a hook
  with caption text.
- Between-stage confirmation before continuing.
- Defer all API ground-truth to marketing-studio; never restate or invent
  preset slugs, parameter shapes, or UUIDs here.
- Keep internals silent unless the user asks how it works.

## 9. Source acknowledgment

Translated from Adil Aliyev's `higgsfield-content-factory` source skill (997
lines). The 5-stage pipeline, the UGC-first 5-format campaign taxonomy with
concept seeds, the even-split allocation math, the button-driven UX
discipline, and the per-batch generation gate are the net-new orchestration
material the v3.7.13 marketing-studio translation deliberately deferred.
Marketing Studio API specifics are **not** re-documented here — they live in
`../higgsfield-marketing-studio/SKILL.md`, which also reconciled several
source-corpus API claims (preset slug naming, avatar handling, the absence of
a `generate_video.mode` slug); this sub-skill honors those reconciliations
and routes all API decisions through it. Default format shares and concept
seeds are craft opinion, presented as overridable defaults, not platform
rules.
